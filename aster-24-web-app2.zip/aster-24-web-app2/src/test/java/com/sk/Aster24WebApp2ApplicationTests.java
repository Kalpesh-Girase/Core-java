package com.sk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aster24WebApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
