package com.sk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aster24WebApp11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
