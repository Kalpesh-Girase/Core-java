package com.sk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aster24WebApp11Application {

	public static void main(String[] args) {
		SpringApplication.run(Aster24WebApp11Application.class, args);
	}

}
