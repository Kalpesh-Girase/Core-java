package com.sk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aster24WebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aster24WebAppApplication.class, args);
	}

}
